# Cover scripts

Deterministic, network-free, stdlib + Pillow (+ optional pypdf). Run in this
order; each reads the previous one's output.

| Script | Does | Fails when |
|---|---|---|
| `cover_spec.py` | spine, bleed, safe areas, barcode zone, ebook size, guide SVG | trim/paper unknown, page count below the binding minimum |
| `cover_prompt.py` | Klein prompts per face, seeds, params, upscale plan | a prompt asks for text, contains a negation, or has no type zone |
| `cover_compose.py` | sets type, builds wrap + ebook + front + SVG master | text leaves the safe area, back copy hits the barcode zone |
| `thumbnail_test.py` | 80/120/240px, greyscale, squint, contrast + busyness | title band under 4.5:1, cover too busy or too pale |
| `cover_preflight.py` | dimensions, DPI, colour mode, file size, barcode fill | anything a retailer would bounce |

Smoke test with no project:

```bash
python cover_spec.py --trim 8.5x11 --pages 108 --paper white --out /tmp/spec.json --guides /tmp/g.svg
KLEIN_SKILL_PATH=/path/to/klein-kids-art python cover_prompt.py --spec /tmp/spec.json \
  --audience early-reader-6-8 --subject "a friendly cartoon triceratops" \
  --action "waving one hand" --setting "a sunny meadow" --print
```
