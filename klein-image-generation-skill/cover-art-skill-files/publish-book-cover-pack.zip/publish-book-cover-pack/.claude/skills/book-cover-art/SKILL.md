---
name: book-cover-art
description: Generate cover artwork with the local Klein-4B (FLUX.2 klein) model through ComfyUI - front hero art with a reserved type zone, low-contrast back art, and spine art where the spine is wide enough. Use after /book-cover-brief, whenever cover artwork needs generating or regenerating, and whenever a cover review sends the artwork back. Never asks the model to render the title; type is set later by /book-cover-compose.
---

# /book-cover-art

Generates the artwork only. Every word on the cover comes later, from a font
file. A prompt that asks Klein for text is a defect and the builder blocks it.

## Steps

**1. Build the audited plan.**

```bash
KLEIN_SKILL_PATH=<path to klein-kids-art> \
python .claude/scripts/cover/cover_prompt.py \
  --spec projects/<id>/visuals/cover/spec.json \
  --audience early-reader-6-8 --book-type coloring-book --pack kids_activity_bold \
  --subject "..." --action "..." --setting "..." \
  --type-zone top-third --faces front,back \
  --out projects/<id>/visuals/cover/art-plan.json --print
```

The plan carries prompts, params, deterministic seeds, the audit result and the
upscale factor needed to reach print resolution. Clear every blocker before
generating anything.

**2. Draft, then finish.** Generate four candidates per face through the ComfyUI
MCP. Draft on the distilled variant if you are exploring composition; render the
keeper on the base variant at the plan's steps. Check the MCP's generate tool
signature before the first call - these servers differ.

**3. Upscale properly.** Klein is reliable to about 2 MP; a 300 DPI print front
needs three to nine. Use a ComfyUI upscale model (4x-UltraSharp or RealESRGAN x4)
and resize down to the plan's `target_front_px`. Flat vector and graphic packs
survive this almost perfectly. Do not let the composer upscale - it uses plain
Lanczos and softens the art.

**4. Judge.** Cropped limbs, fused subjects, uncanny faces, a busy type zone, a
back cover with too much contrast for text to sit on. Then shrink the front to 80
px and confirm the hero still reads. If all four candidates fail the same way,
fix the prompt - see the failure-to-fix table in the klein-kids-art skill.

**5. Save** keepers to `visuals/cover/art/front.png`, `back.png`, `spine.png`,
record prompt, seed, variant and steps for each, and register the artefacts.

## Rules

- No text, no titles, no lettering in any prompt.
- No negations anywhere - Klein has no negative pathway and tends to render what
  you told it to avoid.
- The type zone stays genuinely empty. If it fills with detail, regenerate rather
  than relying on a scrim later.
- No franchises, no real likenesses, no photoreal children, nothing frightening
  on a children's title.
